import { useState, useEffect, type FormEvent } from 'react';
import { X, ShieldCheck, Check, Copy, Lock, Zap, CreditCard, QrCode } from 'lucide-react';

interface CheckoutModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function CheckoutModal({ isOpen, onClose }: CheckoutModalProps) {
  const [paymentMethod, setPaymentMethod] = useState<'pix' | 'card'>('pix');
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [whatsapp, setWhatsapp] = useState('');
  const [cardNumber, setCardNumber] = useState('');
  const [cardExpiry, setCardExpiry] = useState('');
  const [cardCvv, setCardCvv] = useState('');
  const [error, setError] = useState('');
  const [step, setStep] = useState<'form' | 'pix_pending' | 'success'>('form');
  const [copiedPix, setCopiedPix] = useState(false);

  const pixCode =
    '00020126580014br.gov.bcb.pix0136mapa-fornecedores-secreto-27reais520400005303986540527.005802BR5925MAPA FORNECEDORES SECRETO6009SAO PAULO62070503***6304E2A9';

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isOpen) {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const resetAndClose = () => {
    setError('');
    setStep('form');
    setCopiedPix(false);
    onClose();
  };

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    setError('');

    if (name.trim().length < 3) {
      setError('Digite seu nome completo para liberar o acesso.');
      return;
    }
    if (!email.includes('@') || !email.includes('.')) {
      setError('Informe um e-mail válido para receber a lista na hora.');
      return;
    }
    const cleanPhone = whatsapp.replace(/\D/g, '');
    if (cleanPhone.length < 10) {
      setError('Informe seu WhatsApp com DDD (ex: 11 99999-9999).');
      return;
    }

    if (paymentMethod === 'card') {
      if (cardNumber.replace(/\s/g, '').length < 13 || cardExpiry.length < 4 || cardCvv.length < 3) {
        setError('Verifique os dados do cartão para concluir.');
        return;
      }
      setStep('success');
    } else {
      setStep('pix_pending');
    }
  };

  const handleCopyPix = async () => {
    try {
      await navigator.clipboard.writeText(pixCode);
      setCopiedPix(true);
      setTimeout(() => setCopiedPix(false), 2500);
    } catch {
      setCopiedPix(true);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/70 backdrop-blur-xs p-0 sm:p-4"
      role="dialog"
      aria-modal="true"
      aria-labelledby="checkout-title"
    >
      <div className="relative w-full max-w-lg bg-white text-[#0A0A0A] rounded-t-2xl sm:rounded-2xl shadow-2xl border border-neutral-200 max-h-[92vh] overflow-y-auto">
        <div className="sticky top-0 z-10 flex items-center justify-between px-5 py-4 bg-[#0A0A0A] text-white border-b border-neutral-800">
          <div>
            <p className="text-xs font-semibold text-[#BFFF00] tracking-tight">
              Acesso imediato após confirmação
            </p>
            <h2 id="checkout-title" className="text-xl font-extrabold uppercase tracking-tight">
              Mapa dos Fornecedores Secreto
            </h2>
          </div>
          <button
            type="button"
            onClick={resetAndClose}
            aria-label="Fechar checkout"
            className="p-2 rounded-lg text-neutral-400 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-5 sm:p-6">
          {step === 'form' && (
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="flex items-center justify-between p-4 bg-[#F6F7F8] rounded-xl border border-neutral-200">
                <div>
                  <p className="text-sm font-bold text-[#0A0A0A]">
                    Lista Secreta: +80 Fornecedores Premium + 3 Bônus
                  </p>
                  <p className="text-xs text-neutral-600">
                    Envio automático por E-mail e WhatsApp · Garantia 7 dias
                  </p>
                </div>
                <div className="text-right shrink-0 ml-3">
                  <span className="block text-xs line-through text-neutral-500 font-mono tabular-nums">
                    R$ 197,00
                  </span>
                  <span className="font-mono tabular-nums text-2xl font-extrabold text-[#0A0A0A]">
                    R$ 27
                  </span>
                </div>
              </div>

              <div className="space-y-3">
                <div>
                  <label htmlFor="checkout-name" className="block text-xs font-bold text-neutral-700 mb-1">
                    Seu nome completo
                  </label>
                  <input
                    id="checkout-name"
                    type="text"
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="Ex: Rafael Mendes"
                    className="w-full px-3.5 py-2.5 text-sm bg-white border border-neutral-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#0A0A0A]"
                  />
                </div>

                <div>
                  <label htmlFor="checkout-email" className="block text-xs font-bold text-neutral-700 mb-1">
                    Seu melhor e-mail (para receber a lista)
                  </label>
                  <input
                    id="checkout-email"
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="seuemail@gmail.com"
                    className="w-full px-3.5 py-2.5 text-sm bg-white border border-neutral-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#0A0A0A]"
                  />
                </div>

                <div>
                  <label htmlFor="checkout-whatsapp" className="block text-xs font-bold text-neutral-700 mb-1">
                    Seu WhatsApp com DDD (envio instantâneo)
                  </label>
                  <input
                    id="checkout-whatsapp"
                    type="tel"
                    required
                    value={whatsapp}
                    onChange={(e) => setWhatsapp(e.target.value)}
                    placeholder="(11) 99999-9999"
                    className="w-full px-3.5 py-2.5 text-sm bg-white border border-neutral-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#0A0A0A]"
                  />
                </div>
              </div>

              <div>
                <p className="text-xs font-bold text-neutral-700 mb-2">Forma de pagamento</p>
                <div className="grid grid-cols-2 gap-2.5">
                  <button
                    type="button"
                    onClick={() => setPaymentMethod('pix')}
                    className={`flex items-center justify-center gap-2 px-3 py-3 rounded-xl border text-sm font-bold transition-colors cursor-pointer whitespace-nowrap ${
                      paymentMethod === 'pix'
                        ? 'bg-[#0A0A0A] text-[#BFFF00] border-[#0A0A0A]'
                        : 'bg-white text-neutral-700 border-neutral-300 hover:bg-neutral-50'
                    }`}
                  >
                    <QrCode className="w-4 h-4" />
                    Pix (Na hora)
                  </button>
                  <button
                    type="button"
                    onClick={() => setPaymentMethod('card')}
                    className={`flex items-center justify-center gap-2 px-3 py-3 rounded-xl border text-sm font-bold transition-colors cursor-pointer whitespace-nowrap ${
                      paymentMethod === 'card'
                        ? 'bg-[#0A0A0A] text-[#BFFF00] border-[#0A0A0A]'
                        : 'bg-white text-neutral-700 border-neutral-300 hover:bg-neutral-50'
                    }`}
                  >
                    <CreditCard className="w-4 h-4" />
                    Cartão (R$27)
                  </button>
                </div>
              </div>

              {paymentMethod === 'card' && (
                <div className="space-y-3 p-3.5 bg-[#F6F7F8] rounded-xl border border-neutral-200">
                  <div>
                    <label htmlFor="card-number" className="block text-xs font-bold text-neutral-700 mb-1">
                      Número do cartão
                    </label>
                    <input
                      id="card-number"
                      type="text"
                      value={cardNumber}
                      onChange={(e) => setCardNumber(e.target.value)}
                      placeholder="0000 0000 0000 0000"
                      className="w-full px-3 py-2 text-sm bg-white border border-neutral-300 rounded-lg font-mono tabular-nums"
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-2.5">
                    <div>
                      <label htmlFor="card-exp" className="block text-xs font-bold text-neutral-700 mb-1">
                        Validade
                      </label>
                      <input
                        id="card-exp"
                        type="text"
                        value={cardExpiry}
                        onChange={(e) => setCardExpiry(e.target.value)}
                        placeholder="MM/AA"
                        className="w-full px-3 py-2 text-sm bg-white border border-neutral-300 rounded-lg font-mono tabular-nums"
                      />
                    </div>
                    <div>
                      <label htmlFor="card-cvv" className="block text-xs font-bold text-neutral-700 mb-1">
                        CVV
                      </label>
                      <input
                        id="card-cvv"
                        type="text"
                        value={cardCvv}
                        onChange={(e) => setCardCvv(e.target.value)}
                        placeholder="123"
                        className="w-full px-3 py-2 text-sm bg-white border border-neutral-300 rounded-lg font-mono tabular-nums"
                      />
                    </div>
                  </div>
                </div>
              )}

              {error && (
                <p className="text-xs font-semibold text-red-600 bg-red-50 border border-red-200 rounded-lg px-3 py-2">
                  {error}
                </p>
              )}

              <button
                type="submit"
                className="w-full py-4 px-5 bg-[#BFFF00] hover:bg-[#ACE600] text-[#0A0A0A] font-display text-xl font-black uppercase tracking-wide rounded-xl shadow-md transition-colors cursor-pointer flex items-center justify-center gap-2"
              >
                <Zap className="w-5 h-5 fill-current" />
                {paymentMethod === 'pix'
                  ? 'GERAR PIX DE R$27 AGORA'
                  : 'FINALIZAR COMPRA POR R$27'}
              </button>

              <div className="flex items-center justify-center gap-4 pt-1 text-xs text-neutral-500">
                <span className="flex items-center gap-1">
                  <Lock className="w-3.5 h-3.5" /> Compra 100% segura
                </span>
                <span aria-hidden="true">·</span>
                <span className="flex items-center gap-1">
                  <ShieldCheck className="w-3.5 h-3.5" /> Garantia de 7 dias
                </span>
              </div>
            </form>
          )}

          {step === 'pix_pending' && (
            <div className="space-y-4 text-center">
              <div className="inline-flex items-center gap-1.5 text-xs font-bold text-[#0A0A0A] bg-[#BFFF00] px-3 py-1 rounded-md">
                Pix gerado · Valor: R$ 27,00
              </div>

              <h3 className="font-display text-2xl font-extrabold uppercase">
                Escaneie ou copie o código Pix
              </h3>
              <p className="text-sm text-neutral-600">
                Assim que o pagamento de <strong>R$27</strong> for confirmado, enviamos o acesso imediato para <strong>{email}</strong> e <strong>{whatsapp}</strong>.
              </p>

              <div className="mx-auto w-44 h-44 bg-white border-2 border-[#0A0A0A] rounded-xl p-3 flex items-center justify-center">
                <svg viewBox="0 0 100 100" className="w-full h-full text-[#0A0A0A]" aria-label="QR Code Pix">
                  <rect x="4" y="4" width="28" height="28" fill="none" stroke="currentColor" strokeWidth="6" />
                  <rect x="12" y="12" width="12" height="12" fill="currentColor" />
                  <rect x="68" y="4" width="28" height="28" fill="none" stroke="currentColor" strokeWidth="6" />
                  <rect x="76" y="12" width="12" height="12" fill="currentColor" />
                  <rect x="4" y="68" width="28" height="28" fill="none" stroke="currentColor" strokeWidth="6" />
                  <rect x="12" y="76" width="12" height="12" fill="currentColor" />
                  <rect x="40" y="8" width="8" height="8" fill="currentColor" />
                  <rect x="52" y="16" width="8" height="8" fill="currentColor" />
                  <rect x="40" y="28" width="16" height="8" fill="currentColor" />
                  <rect x="8" y="44" width="12" height="8" fill="currentColor" />
                  <rect x="28" y="40" width="8" height="16" fill="currentColor" />
                  <rect x="44" y="44" width="14" height="14" fill="currentColor" />
                  <rect x="66" y="40" width="8" height="12" fill="currentColor" />
                  <rect x="82" y="44" width="14" height="8" fill="currentColor" />
                  <rect x="44" y="68" width="12" height="8" fill="currentColor" />
                  <rect x="64" y="64" width="12" height="12" fill="currentColor" />
                  <rect x="84" y="68" width="12" height="12" fill="currentColor" />
                  <rect x="44" y="84" width="20" height="12" fill="currentColor" />
                  <rect x="74" y="86" width="22" height="10" fill="currentColor" />
                </svg>
              </div>

              <div className="p-3 bg-[#F6F7F8] rounded-xl border border-neutral-200 text-left">
                <p className="text-[11px] font-mono text-neutral-600 truncate mb-2">{pixCode}</p>
                <button
                  type="button"
                  onClick={handleCopyPix}
                  className="w-full py-2.5 px-4 bg-[#0A0A0A] text-white text-xs font-bold rounded-lg hover:bg-neutral-800 transition-colors cursor-pointer flex items-center justify-center gap-2"
                >
                  {copiedPix ? <Check className="w-4 h-4 text-[#BFFF00]" /> : <Copy className="w-4 h-4" />}
                  {copiedPix ? 'Código Pix copiado!' : 'Copiar código Pix Copia e Cola'}
                </button>
              </div>

              <button
                type="button"
                onClick={() => setStep('success')}
                className="w-full py-3.5 px-5 bg-[#BFFF00] hover:bg-[#ACE600] text-[#0A0A0A] font-display text-lg font-black uppercase rounded-xl transition-colors cursor-pointer"
              >
                JÁ FIZ O PIX · LIBERAR ACESSO
              </button>
            </div>
          )}

          {step === 'success' && (
            <div className="py-4 text-center space-y-4">
              <div className="w-14 h-14 mx-auto rounded-full bg-[#BFFF00] text-[#0A0A0A] flex items-center justify-center">
                <Check className="w-8 h-8 stroke-[3]" />
              </div>
              <h3 className="font-display text-3xl font-black uppercase tracking-tight">
                Pedido confirmado!
              </h3>
              <p className="text-sm text-neutral-700 leading-relaxed max-w-sm mx-auto">
                Olá, <strong>{name}</strong>! Seu acesso imediato ao{' '}
                <strong>Mapa dos Fornecedores Secreto</strong> (Mais de 80 Fornecedores Premium + Planilha + Guias + Bônus) foi disparado para:
              </p>
              <div className="p-3.5 bg-[#F6F7F8] rounded-xl border border-neutral-200 text-xs font-medium text-neutral-800 space-y-1">
                <p>E-mail: {email}</p>
                <p>WhatsApp: {whatsapp}</p>
              </div>
              <button
                type="button"
                onClick={resetAndClose}
                className="w-full py-3.5 px-5 bg-[#0A0A0A] text-white font-bold text-sm rounded-xl hover:bg-neutral-800 transition-colors cursor-pointer"
              >
                Voltar para a página
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
