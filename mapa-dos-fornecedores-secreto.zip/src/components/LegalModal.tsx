import { X } from 'lucide-react';

interface LegalModalProps {
  type: 'terms' | 'privacy' | null;
  onClose: () => void;
}

export function LegalModal({ type, onClose }: LegalModalProps) {
  if (!type) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-xs p-4"
      role="dialog"
      aria-modal="true"
    >
      <div className="w-full max-w-lg bg-white text-[#0A0A0A] rounded-2xl border border-neutral-200 shadow-xl overflow-hidden">
        <div className="flex items-center justify-between px-5 py-4 border-b border-neutral-200">
          <h3 className="font-display text-xl font-extrabold uppercase">
            {type === 'terms' ? 'Termos de Uso' : 'Política de Privacidade'}
          </h3>
          <button
            type="button"
            onClick={onClose}
            aria-label="Fechar"
            className="p-1.5 rounded-lg text-neutral-500 hover:text-black hover:bg-neutral-100 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
        <div className="p-5 text-sm text-neutral-700 space-y-3 max-h-[70vh] overflow-y-auto leading-relaxed">
          {type === 'terms' ? (
            <>
              <p>
                O produto digital <strong>Mapa dos Fornecedores Secreto</strong> fornece uma curadoria de contatos comerciais de fornecedores de tênis esportivos, planilhas de precificação e guias informativos.
              </p>
              <p>
                O acesso é pessoal, intransferível e liberado imediatamente após a confirmação do pagamento de R$27,00 por e-mail e WhatsApp.
              </p>
              <p>
                Em conformidade com o Código de Defesa do Consumidor, garantimos 7 dias de reembolso integral e incondicional caso você não fique satisfeito.
              </p>
            </>
          ) : (
            <>
              <p>
                Seus dados informados no momento da compra (nome, e-mail e WhatsApp) são utilizados exclusivamente para o envio imediato do produto digital e suporte ao comprador.
              </p>
              <p>
                Não compartilhamos nem vendemos seus dados pessoais para terceiros. Todas as transações são protegidas com criptografia.
              </p>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
