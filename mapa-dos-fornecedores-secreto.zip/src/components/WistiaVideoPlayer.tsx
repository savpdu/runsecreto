import type { DetailedHTMLProps, HTMLAttributes } from 'react';

declare module 'react' {
  namespace JSX {
    interface IntrinsicElements {
      'wistia-player': DetailedHTMLProps<
        HTMLAttributes<HTMLElement> & {
          'media-id': string;
          aspect?: string;
        },
        HTMLElement
      >;
    }
  }
}

interface WistiaVideoPlayerProps {
  mediaId?: string;
  aspect?: string;
}

export function WistiaVideoPlayer({
  mediaId = 'xnjwl3n805',
  aspect = '0.5625',
}: WistiaVideoPlayerProps) {
  return (
    <div className="max-w-[290px] sm:max-w-[330px] mx-auto mb-6">
      <div className="w-full rounded-2xl overflow-hidden bg-[#0A0A0A] border-2 border-[#0A0A0A] shadow-xl">
        <wistia-player media-id={mediaId} aspect={aspect} />
      </div>
    </div>
  );
}
