import { useState } from 'react';
import { Footprints } from 'lucide-react';

interface SneakerImageProps {
  src: string;
  alt: string;
  title?: string;
  colorway?: string;
  storePrice?: string;
  supplierPrice?: string;
  className?: string;
}

export function SneakerImage({
  src,
  alt,
  title,
  colorway,
  storePrice = 'R$ 899',
  supplierPrice = 'R$ 187',
  className = '',
}: SneakerImageProps) {
  const [hasError, setHasError] = useState(false);

  return (
    <div
      className={`bg-white border border-neutral-200 rounded-xl overflow-hidden flex flex-col ${className}`}
    >
      <div className="relative aspect-square bg-[#F6F7F8] overflow-hidden">
        {!hasError ? (
          <img
            src={src}
            alt={alt}
            referrerPolicy="no-referrer"
            loading="lazy"
            onError={() => setHasError(true)}
            className="w-full h-full object-cover transition-transform duration-300 ease-out hover:scale-[1.03]"
          />
        ) : (
          <div className="w-full h-full flex flex-col items-center justify-center p-4 bg-neutral-100 text-neutral-600 text-center">
            <Footprints className="w-7 h-7 mb-2" />
            <span className="text-xs font-semibold">{title || alt}</span>
          </div>
        )}
      </div>

      <div className="p-3 sm:p-3.5 bg-white border-t border-neutral-200 space-y-2">
        {(title || colorway) && (
          <div>
            {title && (
              <p className="text-sm font-bold text-[#0A0A0A] leading-tight truncate">{title}</p>
            )}
            {colorway && (
              <p className="text-[11px] font-medium text-neutral-500 mt-0.5 truncate">
                {colorway}
              </p>
            )}
          </div>
        )}

        <div className="flex flex-wrap items-center justify-between gap-1.5 pt-0.5">
          <div className="text-xs text-neutral-500 whitespace-nowrap">
            <span>Loja: </span>
            <span className="font-mono tabular-nums line-through font-semibold">{storePrice}</span>
          </div>

          <div className="bg-[#BFFF00] text-[#0A0A0A] px-2.5 py-1 rounded-md font-mono tabular-nums text-xs sm:text-sm font-extrabold whitespace-nowrap">
            Fornecedor {supplierPrice}
          </div>
        </div>
      </div>
    </div>
  );
}
