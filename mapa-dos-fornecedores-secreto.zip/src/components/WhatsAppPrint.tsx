import {
  ArrowLeft,
  Video,
  Phone,
  MoreVertical,
  CheckCheck,
  Smile,
  Paperclip,
  Camera,
  Mic,
} from 'lucide-react';
import type { WhatsAppTestimonial } from '../data/landingData';

interface WhatsAppPrintProps {
  item: WhatsAppTestimonial;
}

export function WhatsAppPrint({ item }: WhatsAppPrintProps) {
  return (
    <article className="rounded-2xl overflow-hidden border border-neutral-300 shadow-md bg-[#EFEAE2] flex flex-col select-none">
      {/* Barra superior autêntica do WhatsApp */}
      <header className="bg-[#008069] text-white px-2.5 py-2 flex items-center justify-between gap-2">
        <div className="flex items-center gap-1.5 min-w-0">
          <ArrowLeft className="w-4 h-4 shrink-0 text-white/95" aria-hidden="true" />
          <img
            src={item.avatar}
            alt={`Foto de ${item.name}`}
            referrerPolicy="no-referrer"
            className="w-9 h-9 rounded-full object-cover object-top shrink-0 bg-neutral-700"
          />
          <div className="min-w-0 ml-1">
            <p className="text-[13px] font-semibold leading-tight truncate text-white">
              {item.name}
            </p>
            <p className="text-[10px] text-white/80 leading-tight truncate mt-0.5">
              {item.statusText}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-3 shrink-0 pr-0.5 text-white/95" aria-hidden="true">
          <Video className="w-4 h-4" />
          <Phone className="w-3.5 h-3.5" />
          <MoreVertical className="w-4 h-4" />
        </div>
      </header>

      {/* Área da conversa com papel de parede clássico do WhatsApp */}
      <div
        className="relative flex-1 px-2.5 py-3 flex flex-col justify-between gap-2 bg-[#EFEAE2]"
        style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg width='80' height='80' viewBox='0 0 80 80' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' stroke='%239c9283' stroke-width='1' stroke-opacity='0.14'%3E%3Ccircle cx='18' cy='18' r='6'/%3E%3Cpath d='M52 12l6 10h-12z'/%3E%3Cpath d='M12 56c4-4 10-4 14 0'/%3E%3Crect x='50' y='48' width='12' height='9' rx='2'/%3E%3Cpath d='M36 32l4 4-4 4-4-4z'/%3E%3C/g%3E%3C/svg%3E")`,
        }}
      >
        <div className="space-y-1.5">
          {/* Chip de data central */}
          <div className="flex justify-center mb-2">
            <span className="bg-white/90 text-[#54656F] text-[10px] font-medium px-2.5 py-0.5 rounded-md shadow-2xs uppercase tracking-wide">
              {item.dayLabel}
            </span>
          </div>

          {/* 1ª bolha recebida (com foto real + legenda) */}
          <div className="relative max-w-[90%] bg-white text-[#111B21] rounded-lg rounded-tl-none p-1 shadow-xs">
            <svg
              viewBox="0 0 8 13"
              width="8"
              height="13"
              className="absolute -left-[7px] top-0 text-white fill-current"
              aria-hidden="true"
            >
              <path d="M1.533 3.568L8 12.193V1H2.812C1.042 1 .474 2.156 1.533 3.568z" />
            </svg>

            {item.photo && (
              <div className="rounded-md overflow-hidden bg-neutral-100">
                <img
                  src={item.photo}
                  alt={`Foto enviada por ${item.name}`}
                  referrerPolicy="no-referrer"
                  loading="lazy"
                  className={`w-full aspect-[4/3] object-cover ${item.photoObjectPosition ?? 'object-center'}`}
                />
              </div>
            )}

            <div className="px-1.5 pt-1.5 pb-1 text-[12px] leading-[1.35]">
              <p>{item.photoCaption}</p>
              <div className="mt-0.5 flex justify-end text-[10px] text-[#667781] leading-none">
                <span>{item.photoTime}</span>
              </div>
            </div>
          </div>

          {/* 2ª bolha recebida (texto do depoimento) */}
          <div className="max-w-[90%] bg-white text-[#111B21] rounded-lg px-2.5 py-1.5 shadow-xs text-[12px] leading-[1.35]">
            <p>{item.message}</p>
            <div className="mt-0.5 flex justify-end text-[10px] text-[#667781] leading-none">
              <span>{item.time}</span>
            </div>
          </div>

          {/* Resposta enviada (verde #D9FDD3 com ✓✓ azul) */}
          <div className="flex justify-end pt-0.5">
            <div className="relative max-w-[85%] bg-[#D9FDD3] text-[#111B21] rounded-lg rounded-tr-none px-2.5 py-1.5 shadow-xs text-[12px] leading-[1.35]">
              <svg
                viewBox="0 0 8 13"
                width="8"
                height="13"
                className="absolute -right-[7px] top-0 text-[#D9FDD3] fill-current"
                aria-hidden="true"
              >
                <path d="M5.188 1H0v11.193l6.467-8.625C7.526 2.156 6.958 1 5.188 1z" />
              </svg>
              <p>{item.reply}</p>
              <div className="mt-0.5 flex items-center justify-end gap-1 text-[10px] text-[#667781] leading-none">
                <span>{item.replyTime}</span>
                <CheckCheck className="w-3.5 h-3.5 text-[#53BDEB]" aria-hidden="true" />
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Barra inferior de digitação do WhatsApp */}
      <div className="bg-[#EFEAE2] px-2 pb-2 pt-1 flex items-center gap-1.5" aria-hidden="true">
        <div className="flex-1 bg-white rounded-full px-2.5 py-1.5 flex items-center justify-between gap-2 shadow-2xs">
          <div className="flex items-center gap-2 min-w-0">
            <Smile className="w-4 h-4 text-[#667781] shrink-0" />
            <span className="text-[12px] text-[#667781] truncate">Mensagem</span>
          </div>
          <div className="flex items-center gap-2 shrink-0 text-[#667781]">
            <Paperclip className="w-3.5 h-3.5 -rotate-45" />
            <Camera className="w-3.5 h-3.5" />
          </div>
        </div>
        <div className="w-8 h-8 rounded-full bg-[#00A884] text-white flex items-center justify-center shrink-0 shadow-2xs">
          <Mic className="w-4 h-4" />
        </div>
      </div>
    </article>
  );
}
