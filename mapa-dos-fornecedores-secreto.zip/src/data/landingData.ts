import avatarRafael from '../assets/images/avatar_rafael_v2_1795550080523.jpg';
import avatarCamila from '../assets/images/avatar_camila_1795550060361.jpg';
import avatarLucas from '../assets/images/avatar_lucas_1795550060880.jpg';
import avatarBruno from '../assets/images/avatar_bruno_v2_1795550080428.jpg';
import avatarThiago from '../assets/images/avatar_thiago_1795550061539.jpg';
import avatarMariana from '../assets/images/avatar_mariana_v2_1795550080700.jpg';

export interface SneakerCard {
  id: string;
  title: string;
  colorway: string;
  image: string;
  storePrice: string;
  supplierPrice: string;
}

export interface WhatsAppTestimonial {
  id: string;
  name: string;
  statusText: string;
  dayLabel: string;
  photoCaption: string;
  photoTime: string;
  time: string;
  message: string;
  reply: string;
  replyTime: string;
  avatar: string;
  photo?: string;
  photoObjectPosition?: string;
}

export interface FaqItem {
  question: string;
  answer: string;
}

export const HERO_SNEAKERS: SneakerCard[] = [
  {
    id: 'hero-branco',
    title: 'Pro Carbon · Branco',
    colorway: 'Mais cores com o fornecedor',
    image: '/assets/aistudio/WhatsApp_Image_2026-11-24_at_12.46.36__1__ba276397.jpeg',
    storePrice: 'R$ 899',
    supplierPrice: 'R$ 187',
  },
  {
    id: 'hero-preto',
    title: 'Pro Carbon · Preto',
    colorway: 'Mais cores com o fornecedor',
    image: '/assets/aistudio/WhatsApp_Image_2026-11-24_at_12.46.36__3__7c1b129d.jpeg',
    storePrice: 'R$ 899',
    supplierPrice: 'R$ 187',
  },
  {
    id: 'hero-neon',
    title: 'Pro Carbon · Neon',
    colorway: 'Mais cores com o fornecedor',
    image: '/assets/aistudio/WhatsApp_Image_2026-11-24_at_12.46.36__2__2da45f60.jpeg',
    storePrice: 'R$ 899',
    supplierPrice: 'R$ 182,88',
  },
];

export const CATALOG_SHOWCASE: SneakerCard[] = [
  {
    id: 'cat-new-1',
    title: 'Adizero Pro Evo 1',
    colorway: 'Várias cores disponíveis',
    image: '/assets/aistudio/image_0d30a915.png',
    storePrice: 'R$ 1.299',
    supplierPrice: 'R$ 220',
  },
  {
    id: 'cat-new-2',
    title: 'Runner Performance Red',
    colorway: 'Várias cores disponíveis',
    image: '/assets/aistudio/image_6403d17b.png',
    storePrice: 'R$ 899',
    supplierPrice: 'R$ 187',
  },
  {
    id: 'cat-new-3',
    title: 'FF Blast+ PureGEL',
    colorway: 'Várias cores disponíveis',
    image: '/assets/aistudio/image_774777f6.png',
    storePrice: 'R$ 999',
    supplierPrice: 'R$ 210',
  },
  {
    id: 'cat-new-4',
    title: 'ZoomX Runner Sálvia',
    colorway: 'Várias cores disponíveis',
    image: '/assets/aistudio/image_b52c0798.png',
    storePrice: 'R$ 899',
    supplierPrice: 'R$ 187',
  },
  {
    id: 'cat-5',
    title: 'Superblast FF Turbo+',
    colorway: 'Várias cores disponíveis',
    image: '/assets/aistudio/WhatsApp_Image_2026-11-24_at_12.46.37__4__05c00627.jpeg',
    storePrice: 'R$ 949',
    supplierPrice: 'R$ 198',
  },
  {
    id: 'cat-6',
    title: 'Cloud Performance Branco',
    colorway: 'Várias cores disponíveis',
    image: '/assets/aistudio/WhatsApp_Image_2026-11-24_at_12.46.35_0dd297c9.jpeg',
    storePrice: 'R$ 899',
    supplierPrice: 'R$ 137',
  },
  {
    id: 'cat-7',
    title: 'Evo Speed SL Neon',
    colorway: 'Várias cores disponíveis',
    image: '/assets/aistudio/WhatsApp_Image_2026-11-24_at_12.46.37_efac88db.jpeg',
    storePrice: 'R$ 899',
    supplierPrice: 'R$ 234,65',
  },
  {
    id: 'cat-8',
    title: 'Evo Speed SL Preto',
    colorway: 'Várias cores disponíveis',
    image: '/assets/aistudio/WhatsApp_Image_2026-11-24_at_12.46.36__4__30aaad0f.jpeg',
    storePrice: 'R$ 899',
    supplierPrice: 'R$ 199,50',
  },
];

export const WHAT_YOU_GET = [
  'Lista com mais de 80 Fornecedores Premium de Tênis de Corrida (PDF + Planilha)',
  'Contato direto: WhatsApp e Instagram de cada fornecedor',
  'Preço de custo de cada modelo (a partir de R$97)',
  'Guia: Como comprar sem cair em golpe',
  'Guia: Como revender e lucrar R$200 por par',
];

export const BONUSES = [
  {
    number: 'Bônus 1',
    title: 'Planilha de Precificação para Revenda',
    value: 'Vale R$97',
  },
  {
    number: 'Bônus 2',
    title: '10 Legendas prontas para vender no Instagram',
    value: 'Vale R$47',
  },
  {
    number: 'Bônus 3',
    title: 'Grupo de suporte no WhatsApp',
    value: 'Incluso',
  },
];

export const WHATSAPP_TESTIMONIALS: WhatsAppTestimonial[] = [
  {
    id: 'dep-1',
    name: 'Rafael Mendes · SP',
    statusText: 'visto por último hoje às 10:14',
    dayLabel: 'Hoje',
    photoCaption: 'Olha aí, acabou de chegar tudo certinho aqui em casa 📦🔥',
    photoTime: '09:41',
    time: '09:42',
    message:
      'Comprei 3 pares por R$540 com os fornecedores, na loja ia dar R$2.700. Veio na caixa e com frete grátis!',
    reply: 'Show demais Rafael!! Aproveita muito e bons treinos 💪',
    replyTime: '09:45',
    avatar: avatarRafael,
    photo: '/assets/aistudio/WhatsApp_Image_2026-11-24_at_16.30.19__1__dfee4b45.jpeg',
    photoObjectPosition: 'object-center',
  },
  {
    id: 'dep-2',
    name: 'Camila Ferreira · MG',
    statusText: 'online',
    dayLabel: 'Hoje',
    photoCaption: 'Mais um que chegou hoje pra entrega 😍',
    photoTime: '14:16',
    time: '14:18',
    message:
      'Vendi 4 pares antes mesmo de fazer o pedido. Paguei R$187 em cada e vendi a R$450. Lucro de mais de R$1.000 na semana!',
    reply: 'Braba demais Camila!! Bora pra cima 🚀',
    replyTime: '14:20',
    avatar: avatarCamila,
    photo: '/assets/aistudio/WhatsApp_Image_2026-11-24_at_12.46.36__5__64b26427.jpeg',
    photoObjectPosition: 'object-center',
  },
  {
    id: 'dep-3',
    name: 'Lucas Andrade · PR',
    statusText: 'visto por último hoje às 18:32',
    dayLabel: 'Ontem',
    photoCaption: 'Testando no pé agora, leve demais 🏃‍♂️💨',
    photoTime: '18:03',
    time: '18:05',
    message:
      'Peguei esse modelo por R$187 com um fornecedor da lista. Acabamento absurdo, zero risco e chegou rápido aqui em Curitiba.',
    reply: 'Ficou top no pé Lucas! Excelente corrida 🙌',
    replyTime: '18:08',
    avatar: avatarLucas,
    photo: '/assets/aistudio/WhatsApp_Image_2026-11-24_at_16.30.19__3__bcdea32c.jpeg',
    photoObjectPosition: 'object-center',
  },
  {
    id: 'dep-4',
    name: 'Bruno Carvalho · CE',
    statusText: 'visto por último hoje às 12:05',
    dayLabel: 'Hoje',
    photoCaption: 'Primeiro pedido no meu CPF acabou de chegar 🙌',
    photoTime: '11:27',
    time: '11:29',
    message:
      'Sem frete e sem dor de cabeça. Agora já tô com 6 encomendas fechadas pro mês que vem!',
    reply: 'Isso aí Bruno, sem precisar de estoque! Sucesso 🔥',
    replyTime: '11:32',
    avatar: avatarBruno,
    photo: '/assets/aistudio/WhatsApp_Image_2026-11-24_at_16.30.19__2__cfef68e3.jpeg',
    photoObjectPosition: 'object-[50%_75%]',
  },
  {
    id: 'dep-5',
    name: 'Thiago Nogueira · RJ',
    statusText: 'visto por último hoje às 20:41',
    dayLabel: 'Ontem',
    photoCaption: 'Chegou agora aqui no RJ, qualidade absurda 👌',
    photoTime: '20:12',
    time: '20:14',
    message:
      'O guia anti-golpe + os contatos do Mapa salvaram demais. Paguei R$27 na lista e no 1º par já recuperei 25x o valor.',
    reply: 'Valeu pelo retorno Thiago! Tamo junto 🤝',
    replyTime: '20:16',
    avatar: avatarThiago,
    photo: '/assets/aistudio/WhatsApp_Image_2026-11-24_at_12.46.37__1__e4ec3fad.jpeg',
    photoObjectPosition: 'object-center',
  },
  {
    id: 'dep-6',
    name: 'Mariana Costa · RS',
    statusText: 'online',
    dayLabel: 'Hoje',
    photoCaption: 'Mais um da remessa que saiu hoje aqui na academia 👟✨',
    photoTime: '16:49',
    time: '16:51',
    message:
      'Usei as legendas do bônus no Instagram, vendi 3 pares pra galera daqui no mesmo dia e tirei R$780 de lucro!',
    reply: 'Sensacional Mariana!! Boas vendas 🚀',
    replyTime: '16:54',
    avatar: avatarMariana,
    photo: '/assets/aistudio/WhatsApp_Image_2026-11-24_at_12.46.35__4__1fc86c19.jpeg',
    photoObjectPosition: 'object-center',
  },
];

export const FAQ_ITEMS: FaqItem[] = [
  {
    question: 'Os fornecedores são confiáveis?',
    answer: 'Sim, todos os mais de 80 fornecedores premium foram testados e atualizados em 2026.',
  },
  {
    question: 'Preciso ter CNPJ para comprar?',
    answer: 'Não, você compra normalmente no seu CPF (a partir de 1 par).',
  },
  {
    question: 'Tem variação de cores e modelos com os fornecedores?',
    answer:
      'Sim! Cada fornecedor da lista possui catálogo completo com várias cores e numerações disponíveis para você escolher direto pelo WhatsApp.',
  },
  {
    question: 'Como recebo?',
    answer: 'Na hora, por e-mail e WhatsApp imediatamente após a confirmação do pagamento.',
  },
  {
    question: 'E se eu não gostar?',
    answer: 'Você tem 7 dias de garantia incondicional. Devolvo 100% do seu dinheiro.',
  },
  {
    question: 'Posso revender?',
    answer: 'Sim, é o maior lucro do produto — você lucra R$200 a R$400 por par sem precisar de estoque.',
  },
];
