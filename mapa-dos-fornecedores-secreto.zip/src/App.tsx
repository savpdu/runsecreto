import { useState } from 'react';
import {
  Check,
  X,
  ShieldCheck,
  ChevronDown,
  ArrowRight,
  Lock,
  Zap,
  Palette,
} from 'lucide-react';
import {
  HERO_SNEAKERS,
  CATALOG_SHOWCASE,
  WHAT_YOU_GET,
  BONUSES,
  WHATSAPP_TESTIMONIALS,
  FAQ_ITEMS,
} from './data/landingData';
import { SneakerImage } from './components/SneakerImage';
import { WhatsAppPrint } from './components/WhatsAppPrint';
import { WistiaVideoPlayer } from './components/WistiaVideoPlayer';
import { LegalModal } from './components/LegalModal';

const CHECKOUT_URL = 'https://pay.wiapy.com/o_Df4YIvEP1u';

export default function App() {
  const [legalModal, setLegalModal] = useState<'terms' | 'privacy' | null>(null);
  const [openFaqIndex, setOpenFaqIndex] = useState<number | null>(0);

  const trackInitiateCheckout = () => {
    const win = window as Window & {
      fbq?: (command: string, eventName: string, params?: Record<string, unknown>) => void;
    };
    if (typeof win.fbq === 'function') {
      win.fbq('track', 'InitiateCheckout', { value: 27, currency: 'BRL' });
    }
  };

  return (
    <div className="min-h-screen bg-white text-[#0A0A0A] pb-20 md:pb-0">
      {/* Faixa superior de urgência */}
      <header className="sticky top-0 z-40 bg-[#0A0A0A] text-[#BFFF00] border-b border-neutral-800">
        <div className="max-w-5xl mx-auto px-4 h-10 flex items-center justify-center">
          <p className="font-display text-sm sm:text-base font-black uppercase tracking-wider text-center">
            Somente hoje esse preço
          </p>
        </div>
      </header>

      <main id="topo">
        {/* 1. HERO - PRIMEIRA DOBRA */}
        <section className="pt-8 pb-12 sm:pt-12 sm:pb-16 px-4 sm:px-6 border-b border-neutral-200">
          <div className="max-w-5xl mx-auto">
            <div className="max-w-3xl mx-auto text-center">
              <p className="text-xs sm:text-sm font-semibold text-neutral-600 mb-3">
                Mapa dos Fornecedores Secreto (Atualizada 2026)
              </p>

              <h1 className="font-display text-[2.2rem] sm:text-5xl lg:text-[3.35rem] font-black uppercase leading-[0.98] tracking-tight text-[#0A0A0A] text-balance mb-5">
                Mais De 80 Fornecedores Premium De Tênis De Corrida{' '}
                <span className="bg-[#BFFF00] px-2 rounded-md inline-block">Pra Você Comprar Barato</span>
              </h1>

              <WistiaVideoPlayer mediaId="xnjwl3n805" aspect="0.5625" />

              <p className="text-base sm:text-lg text-neutral-700 leading-relaxed max-w-2xl mx-auto mb-6">
                Compre os tênis mais desejados de corrida a partir de{' '}
                <strong>R$97</strong> direto do fornecedor, com{' '}
                <strong className="bg-[#BFFF00] text-[#0A0A0A] px-1.5 py-0.5 rounded font-extrabold">
                  frete grátis sem risco
                </strong>{' '}
                direto pra sua casa.
              </p>

              <div className="flex flex-col items-center">
                <a
                  href={CHECKOUT_URL}
                  target="_blank"
                  rel="noopener noreferrer"
                  onClick={trackInitiateCheckout}
                  className="w-full sm:w-auto px-8 sm:px-10 py-4 bg-[#BFFF00] hover:bg-[#ACE600] text-[#0A0A0A] font-display text-2xl font-black uppercase tracking-wide rounded-xl shadow-[0_5px_0_0_#0A0A0A] active:translate-y-0.5 transition-all cursor-pointer flex items-center justify-center gap-2 border-2 border-[#0A0A0A]"
                >
                  <span>QUERO A LISTA POR R$27</span>
                  <ArrowRight className="w-5 h-5 stroke-[2.5]" />
                </a>

                <p className="mt-3.5 text-xs sm:text-sm font-semibold text-neutral-600">
                  Acesso imediato | +1.873 pessoas já compraram | Garantia de 7 dias
                </p>
              </div>
            </div>

            {/* 3 fotos lado a lado: branco, preto e neon */}
            <div className="mt-9 grid grid-cols-1 sm:grid-cols-3 gap-4">
              {HERO_SNEAKERS.map((shoe) => (
                <SneakerImage
                  key={shoe.id}
                  src={shoe.image}
                  alt={`${shoe.title} — Loja ${shoe.storePrice}, Fornecedor ${shoe.supplierPrice}`}
                  title={shoe.title}
                  colorway={shoe.colorway}
                  storePrice={shoe.storePrice}
                  supplierPrice={shoe.supplierPrice}
                />
              ))}
            </div>

            <p className="mt-4 text-center text-xs sm:text-sm font-semibold text-neutral-700 flex items-center justify-center gap-1.5">
              <Palette className="w-4 h-4 shrink-0" />
              <span>Variação de cores e numerações disponível diretamente com os fornecedores.</span>
            </p>
          </div>
        </section>

        {/* 2. PRA QUEM É */}
        <section id="para-quem-e" className="py-12 sm:py-16 px-4 sm:px-6 bg-[#F6F7F8] border-b border-neutral-200">
          <div className="max-w-4xl mx-auto">
            <h2 className="font-display text-3xl sm:text-4xl font-black uppercase tracking-tight text-center mb-8">
              Pra Quem É Essa Lista
            </h2>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="bg-white p-6 rounded-2xl border border-neutral-200 space-y-3.5">
                <div className="flex items-start gap-3">
                  <Check className="w-5 h-5 text-[#0A0A0A] bg-[#BFFF00] rounded p-0.5 shrink-0 mt-0.5 stroke-[3]" />
                  <p className="text-sm sm:text-base font-medium text-neutral-800">
                    Para quem <strong>corre</strong> e quer pagar barato no seu tênis.
                  </p>
                </div>
                <div className="flex items-start gap-3">
                  <Check className="w-5 h-5 text-[#0A0A0A] bg-[#BFFF00] rounded p-0.5 shrink-0 mt-0.5 stroke-[3]" />
                  <p className="text-sm sm:text-base font-medium text-neutral-800">
                    Para quem quer <strong>revender tênis</strong> e lucrar R$200–R$400 por par.
                  </p>
                </div>
                <div className="flex items-start gap-3">
                  <Check className="w-5 h-5 text-[#0A0A0A] bg-[#BFFF00] rounded p-0.5 shrink-0 mt-0.5 stroke-[3]" />
                  <p className="text-sm sm:text-base font-medium text-neutral-800">
                    Para quem está cansado de pagar <strong>R$899 na loja</strong>.
                  </p>
                </div>
              </div>

              <div className="bg-[#0A0A0A] text-white p-6 rounded-2xl flex flex-col justify-center space-y-4">
                <div className="flex items-start gap-3">
                  <X className="w-5 h-5 text-red-400 shrink-0 mt-0.5 stroke-[3]" />
                  <p className="text-sm sm:text-base text-neutral-200">
                    <strong className="text-[#BFFF00]">NÃO é</strong> para quem quer ficar só olhando e continuar pagando caro na vitrine.
                  </p>
                </div>
                <a
                  href={CHECKOUT_URL}
                  target="_blank"
                  rel="noopener noreferrer"
                  onClick={trackInitiateCheckout}
                  className="w-full py-3 px-4 bg-[#BFFF00] hover:bg-[#ACE600] text-[#0A0A0A] font-display text-lg font-black uppercase rounded-xl cursor-pointer transition-colors block text-center"
                >
                  QUERO A LISTA POR R$27
                </a>
              </div>
            </div>
          </div>
        </section>

        {/* 3. A DOR */}
        <section className="py-12 sm:py-16 px-4 sm:px-6 bg-white border-b border-neutral-200">
          <div className="max-w-4xl mx-auto">
            <h2 className="font-display text-3xl sm:text-4xl font-black uppercase tracking-tight text-center mb-8">
              O Que Acontece Quando Você Não Tem Os Contatos Certos
            </h2>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="p-5 bg-[#F6F7F8] rounded-xl border border-neutral-200">
                <p className="text-sm sm:text-base text-neutral-800 leading-relaxed">
                  Você paga <strong>R$899</strong> no tênis, depois descobre que o lojista comprou por <strong>R$97 a R$210</strong> do mesmo fornecedor.
                </p>
              </div>
              <div className="p-5 bg-[#F6F7F8] rounded-xl border border-neutral-200">
                <p className="text-sm sm:text-base text-neutral-800 leading-relaxed">
                  Você corre com tênis pesado e barato porque acha que tênis bom é caro demais.
                </p>
              </div>
              <div className="p-5 bg-[#F6F7F8] rounded-xl border border-neutral-200">
                <p className="text-sm sm:text-base text-neutral-800 leading-relaxed">
                  Você quer revender, mas não acha fornecedor confiável e acaba caindo em golpe.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* 4. A SOLUÇÃO + MODELOS */}
        <section id="solucao" className="py-12 sm:py-16 px-4 sm:px-6 bg-[#0A0A0A] text-white">
          <div className="max-w-5xl mx-auto">
            <div className="max-w-3xl mx-auto text-center mb-10 space-y-3">
              <p className="text-xs font-bold uppercase tracking-wider text-[#BFFF00]">
                Lista atualizada em 2026
              </p>
              <h2 className="font-display text-3xl sm:text-5xl font-black uppercase tracking-tight text-balance">
                Mapa Dos Fornecedores Secreto: Mais De 80 Fornecedores Premium
              </h2>
              <p className="text-sm sm:text-base text-neutral-300 leading-relaxed">
                Todos os mais de 80 fornecedores de tênis de corrida são <strong>testados e verificados pra você comprar barato</strong>, com WhatsApp, Instagram, tabela de preços, mínimo de pedido (a partir de 1 par no CPF), <strong>envio sem risco e frete grátis</strong> direto pra sua casa em todo o Brasil.
              </p>
              <p className="text-xs sm:text-sm font-bold text-[#BFFF00]">
                Você escolhe o modelo e confere toda a variação de cores diretamente com os fornecedores.
              </p>
            </div>

            {/* Grade limpa com todos os novos modelos + principais */}
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
              {CATALOG_SHOWCASE.map((shoe) => (
                <SneakerImage
                  key={shoe.id}
                  src={shoe.image}
                  alt={shoe.title}
                  title={shoe.title}
                  colorway={shoe.colorway}
                  storePrice={shoe.storePrice}
                  supplierPrice={shoe.supplierPrice}
                />
              ))}
            </div>

            <div className="mt-8 text-center">
              <a
                href={CHECKOUT_URL}
                target="_blank"
                rel="noopener noreferrer"
                onClick={trackInitiateCheckout}
                className="w-full sm:w-auto px-8 py-4 bg-[#BFFF00] hover:bg-[#ACE600] text-[#0A0A0A] font-display text-xl sm:text-2xl font-black uppercase rounded-xl cursor-pointer inline-flex items-center justify-center gap-2 transition-colors"
              >
                <span>ACESSAR +80 FORNECEDORES POR R$27</span>
                <ArrowRight className="w-5 h-5" />
              </a>
            </div>
          </div>
        </section>

        {/* 5. O QUE VOCÊ VAI RECEBER */}
        <section className="py-12 sm:py-16 px-4 sm:px-6 bg-white border-b border-neutral-200">
          <div className="max-w-3xl mx-auto">
            <h2 className="font-display text-3xl sm:text-4xl font-black uppercase tracking-tight text-center mb-8">
              O Que Você Vai Receber
            </h2>

            <div className="space-y-3">
              {WHAT_YOU_GET.map((item) => (
                <div
                  key={item}
                  className="p-4 sm:p-5 bg-[#F6F7F8] rounded-xl border border-neutral-200 flex items-center gap-3.5"
                >
                  <span className="w-7 h-7 rounded-lg bg-[#BFFF00] text-[#0A0A0A] flex items-center justify-center shrink-0 border border-[#0A0A0A]/15">
                    <Check className="w-4 h-4 stroke-[3]" />
                  </span>
                  <span className="text-sm sm:text-base font-bold text-[#0A0A0A]">{item}</span>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* 6. BENEFÍCIOS + 7. BÔNUS EXCLUSIVOS */}
        <section className="py-12 sm:py-16 px-4 sm:px-6 bg-[#F6F7F8] border-b border-neutral-200">
          <div className="max-w-5xl mx-auto space-y-12">
            {/* Benefícios */}
            <div>
              <h2 className="font-display text-3xl sm:text-4xl font-black uppercase tracking-tight text-center mb-7">
                Benefícios Diretos
              </h2>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3.5">
                {[
                  { title: 'Economize R$600+ por par', desc: 'Pague R$97–R$235 em tênis de R$899.' },
                  { title: 'Compre 2, 3 modelos', desc: 'Monte seu rodízio gastando menos que 1 par na loja.' },
                  { title: 'Revenda no mesmo dia', desc: 'Receba os contatos na hora e comece hoje.' },
                  { title: 'Sem estoque e frete grátis', desc: 'Compre só depois que vender, com envio sem risco.' },
                ].map((b) => (
                  <div key={b.title} className="bg-white p-5 rounded-xl border border-neutral-200">
                    <h3 className="font-display text-xl font-extrabold uppercase text-[#0A0A0A]">
                      {b.title}
                    </h3>
                    <p className="text-sm text-neutral-600 mt-1">{b.desc}</p>
                  </div>
                ))}
              </div>
            </div>

            {/* Bônus */}
            <div>
              <h2 className="font-display text-3xl sm:text-4xl font-black uppercase tracking-tight text-center mb-7">
                Bônus Exclusivos Grátis Hoje
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {BONUSES.map((bonus) => (
                  <div
                    key={bonus.number}
                    className="p-5 bg-[#0A0A0A] text-white rounded-xl border border-neutral-800 flex flex-col justify-between gap-2"
                  >
                    <div className="flex items-center justify-between text-xs font-bold">
                      <span className="text-[#BFFF00] uppercase">{bonus.number}</span>
                      <span className="text-neutral-400 font-mono">{bonus.value}</span>
                    </div>
                    <h3 className="font-display text-xl font-extrabold uppercase leading-snug">
                      {bonus.title}
                    </h3>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* 8. DEPOIMENTOS (6 prints WhatsApp) */}
        <section id="depoimentos" className="py-12 sm:py-16 px-4 sm:px-6 bg-white border-b border-neutral-200">
          <div className="max-w-5xl mx-auto">
            <h2 className="font-display text-3xl sm:text-4xl font-black uppercase tracking-tight text-center mb-8">
              Quem Já Comprou Aprova
            </h2>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
              {WHATSAPP_TESTIMONIALS.map((item) => (
                <WhatsAppPrint key={item.id} item={item} />
              ))}
            </div>
          </div>
        </section>

        {/* 9. OFERTA */}
        <section id="oferta" className="py-12 sm:py-16 px-4 sm:px-6 bg-[#F6F7F8] border-b border-neutral-200">
          <div className="max-w-xl mx-auto bg-[#0A0A0A] text-white rounded-2xl p-6 sm:p-9 text-center space-y-4 border-2 border-[#0A0A0A] shadow-xl">
            <p className="text-xs font-bold uppercase tracking-wider text-[#BFFF00]">
              Mapa dos Fornecedores Secreto + 3 Bônus
            </p>
            <h2 className="font-display text-3xl sm:text-4xl font-black uppercase">
              Acesso Completo Hoje
            </h2>

            <div>
              <p className="text-sm text-neutral-400 font-semibold">
                De <span className="line-through font-mono">R$197</span> por apenas:
              </p>
              <p className="font-display text-6xl font-black text-[#BFFF00] tabular-nums leading-none mt-1">
                R$27
              </p>
              <p className="text-xs sm:text-sm font-semibold text-neutral-300 mt-1">
                À vista ou no Pix · Acesso imediato após confirmação do pagamento
              </p>
            </div>

            <a
              href={CHECKOUT_URL}
              target="_blank"
              rel="noopener noreferrer"
              onClick={trackInitiateCheckout}
              className="w-full py-4 px-5 bg-[#BFFF00] hover:bg-[#ACE600] text-[#0A0A0A] font-display text-2xl font-black uppercase rounded-xl cursor-pointer flex items-center justify-center gap-2 transition-colors"
            >
              <span>QUERO ACESSO IMEDIATO POR R$27</span>
              <ArrowRight className="w-5 h-5 stroke-[2.5]" />
            </a>

            <div className="flex flex-wrap items-center justify-center gap-3 text-xs text-neutral-400 pt-1">
              <span className="flex items-center gap-1">
                <Lock className="w-3.5 h-3.5 text-[#BFFF00]" /> Pagamento seguro
              </span>
              <span aria-hidden="true">·</span>
              <span className="flex items-center gap-1">
                <Zap className="w-3.5 h-3.5 text-[#BFFF00]" /> Entrega na hora por e-mail e WhatsApp
              </span>
            </div>
          </div>
        </section>

        {/* 10. DÚVIDAS FREQUENTES */}
        <section id="duvidas" className="py-12 sm:py-16 px-4 sm:px-6 bg-white border-b border-neutral-200">
          <div className="max-w-3xl mx-auto">
            <h2 className="font-display text-3xl sm:text-4xl font-black uppercase tracking-tight text-center mb-7">
              Dúvidas Frequentes
            </h2>

            <div className="space-y-2.5">
              {FAQ_ITEMS.map((faq, index) => {
                const isOpen = openFaqIndex === index;
                return (
                  <div
                    key={faq.question}
                    className="bg-[#F6F7F8] rounded-xl border border-neutral-200 overflow-hidden"
                  >
                    <button
                      type="button"
                      onClick={() => setOpenFaqIndex(isOpen ? null : index)}
                      aria-expanded={isOpen}
                      className="w-full px-5 py-3.5 text-left flex items-center justify-between gap-4 cursor-pointer"
                    >
                      <span className="text-sm sm:text-base font-extrabold text-[#0A0A0A]">
                        {faq.question}
                      </span>
                      <ChevronDown
                        className={`w-5 h-5 text-neutral-600 shrink-0 transition-transform ${
                          isOpen ? 'rotate-180' : ''
                        }`}
                      />
                    </button>
                    {isOpen && (
                      <div className="px-5 pb-3.5 text-sm text-neutral-700 leading-relaxed border-t border-neutral-200 pt-2.5 bg-white">
                        {faq.answer}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        </section>

        {/* 11. GARANTIA */}
        <section className="py-12 sm:py-16 px-4 sm:px-6 bg-[#F6F7F8] border-b border-neutral-200">
          <div className="max-w-3xl mx-auto bg-white rounded-2xl p-6 sm:p-8 border border-neutral-200 flex flex-col sm:flex-row items-center gap-6 text-center sm:text-left">
            <div className="w-28 h-28 rounded-full bg-[#0A0A0A] text-[#BFFF00] border-4 border-[#BFFF00] flex flex-col items-center justify-center shrink-0">
              <ShieldCheck className="w-6 h-6" />
              <span className="font-display text-3xl font-black leading-none mt-0.5">7 DIAS</span>
              <span className="text-[9px] font-bold uppercase text-white">Garantia Total</span>
            </div>

            <div className="space-y-2">
              <h2 className="font-display text-2xl sm:text-3xl font-black uppercase">
                Garantia Incondicional De 7 Dias
              </h2>
              <p className="text-sm text-neutral-700 leading-relaxed">
                Acesse a lista com mais de 80 fornecedores premium agora. Se não gostar por qualquer motivo em até 7 dias, devolvemos 100% dos seus R$27 sem burocracia.
              </p>
            </div>
          </div>
        </section>
      </main>

      {/* 12. RODAPÉ */}
      <footer className="py-8 px-4 sm:px-6 bg-[#0A0A0A] text-neutral-400 text-center text-xs space-y-2">
        <p>Este produto não garante resultados, seus resultados dependem da sua aplicação.</p>
        <div className="flex items-center justify-center gap-3 font-semibold text-neutral-300">
          <button
            type="button"
            onClick={() => setLegalModal('terms')}
            className="hover:text-[#BFFF00] cursor-pointer"
          >
            Termos
          </button>
          <span aria-hidden="true">|</span>
          <button
            type="button"
            onClick={() => setLegalModal('privacy')}
            className="hover:text-[#BFFF00] cursor-pointer"
          >
            Privacidade
          </button>
        </div>
      </footer>

      {/* Botão fixo no celular */}
      <div className="fixed bottom-0 inset-x-0 z-40 md:hidden bg-white/95 backdrop-blur-xs border-t border-neutral-200 px-3 py-2">
        <a
          href={CHECKOUT_URL}
          target="_blank"
          rel="noopener noreferrer"
          onClick={trackInitiateCheckout}
          className="w-full h-11 bg-[#BFFF00] hover:bg-[#ACE600] text-[#0A0A0A] font-display text-lg font-black uppercase rounded-xl border border-[#0A0A0A] flex items-center justify-center gap-2 cursor-pointer"
        >
          <span>QUERO A LISTA POR R$27</span>
          <ArrowRight className="w-4 h-4 stroke-[2.5]" />
        </a>
      </div>

      <LegalModal type={legalModal} onClose={() => setLegalModal(null)} />
    </div>
  );
}
